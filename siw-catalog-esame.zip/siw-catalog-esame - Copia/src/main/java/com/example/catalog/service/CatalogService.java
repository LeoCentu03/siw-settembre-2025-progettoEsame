package com.example.catalog.service;

import com.example.catalog.model.Product;
import com.example.catalog.repo.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CatalogService {

    private final ProductRepository repository;

    public CatalogService(ProductRepository repository) {
        this.repository = repository;
    }

    public List<Product> findAll() {
        return repository.findAllByOrderByNameAsc();
    }

    public List<Product> findByType(String type) {
        return repository.findByTypeIgnoreCaseOrderByNameAsc(type);
    }

    public List<Product> findByName(String name) {
        return repository.findByNameContainingIgnoreCaseOrderByNameAsc(name);
    }
}
