package com.example.catalog.web;

import com.example.catalog.model.Comment;
import com.example.catalog.model.Product;
import com.example.catalog.service.ProductService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/products/{id}")
    public String detail(@PathVariable("id") Long id, Model m) {
        Product p = productService.getProductWithSimilar(id);
        List<Product> similar = productService.getSimilarProducts(p);
        List<Comment> list = productService.getComments(p);

        m.addAttribute("title", p.getName());
        m.addAttribute("p", p);
        m.addAttribute("similar", similar);
        m.addAttribute("comments", list);
        m.addAttribute("newComment", new Comment());
        return "product_detail";
    }
}
