package com.example.catalog.service;

import com.example.catalog.model.Comment;
import com.example.catalog.model.Product;
import com.example.catalog.repo.CommentRepository;
import com.example.catalog.repo.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDateTime;

@Service
public class CommentService {

    private final CommentRepository commentRepository;
    private final ProductRepository productRepository;

    public CommentService(CommentRepository commentRepository, ProductRepository productRepository) {
        this.commentRepository = commentRepository;
        this.productRepository = productRepository;
    }

    public Comment create(Long productId, Comment form, Authentication auth) {
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        Comment comment = new Comment();
        comment.setProduct(product);
        comment.setText(form.getText());
        comment.setAuthorUsername(auth != null ? auth.getName() : "anon");
        comment.setCreatedAt(LocalDateTime.now());

        return commentRepository.save(comment);
    }

    public Comment findById(Long id) {
        return commentRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public Comment update(Long id, Comment form, Authentication auth) {
        Comment comment = findById(id);
        if (!canManage(auth, comment))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);

        comment.setText(form.getText());
        return commentRepository.save(comment);
    }

    public void delete(Long id, Authentication auth) {
        Comment comment = findById(id);
        if (!canManage(auth, comment))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN);

        commentRepository.delete(comment);
    }

    private boolean canManage(Authentication auth, Comment c) {
        if (auth == null) return false;
        if (auth.getName().equals(c.getAuthorUsername())) return true;
        return auth.getAuthorities().stream()
                .anyMatch(a -> "ROLE_ADMIN".equals(a.getAuthority()));
    }
}
