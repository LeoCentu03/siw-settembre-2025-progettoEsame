package com.example.catalog.web;

import com.example.catalog.model.Comment;
import com.example.catalog.service.CommentService;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/comments")
public class CommentController {

    private final CommentService commentService;

    public CommentController(CommentService commentService) {
        this.commentService = commentService;
    }

    @PostMapping("/product/{productId}")
    public String create(@PathVariable("productId") Long productId,
                         @ModelAttribute Comment form,
                         Authentication auth,
                         RedirectAttributes ra) {
        commentService.create(productId, form, auth);
        ra.addFlashAttribute("message", "Commento pubblicato");
        return "redirect:/products/" + productId;
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable("id") Long id,
                           Authentication auth,
                           Model model) {
        Comment comment = commentService.findById(id);
        model.addAttribute("comment", comment);
        model.addAttribute("productId", comment.getProduct().getId());
        return "comments/edit";
    }

    @PostMapping("/{id}/update")
    public String update(@PathVariable("id") Long id,
                         @ModelAttribute Comment form,
                         Authentication auth,
                         RedirectAttributes ra) {
        Comment updated = commentService.update(id, form, auth);
        ra.addFlashAttribute("message", "Commento aggiornato");
        return "redirect:/products/" + updated.getProduct().getId();
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable("id") Long id,
                         Authentication auth,
                         RedirectAttributes ra) {
        Long productId = commentService.findById(id).getProduct().getId();
        commentService.delete(id, auth);
        ra.addFlashAttribute("message", "Commento eliminato");
        return "redirect:/products/" + productId;
    }
}
