package com.example.catalog.web;

import com.example.catalog.model.Product;
import com.example.catalog.service.CatalogService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Controller
public class CatalogController {

    private final CatalogService catalogService;

    public CatalogController(CatalogService catalogService) {
        this.catalogService = catalogService;
    }

    @GetMapping("/")
    public String index(Model model) {
        List<String> types = catalogService.findAll().stream()
                .map(Product::getType)
                .filter(Objects::nonNull)
                .map(String::toLowerCase)
                .distinct()
                .sorted()
                .collect(Collectors.toList());

        model.addAttribute("types", types);
        model.addAttribute("products", catalogService.findAll());
        return "index";
    }

    @GetMapping("/products")
    public String byTypeOrName(@RequestParam(name = "type", required = false) String type,
                                @RequestParam(name = "name", required = false) String name,
                                Model model) {
        List<Product> list;

        if (type != null && !type.trim().isEmpty()) {
            list = catalogService.findByType(type);
        } else if (name != null && !name.trim().isEmpty()) {
            list = catalogService.findByName(name);
        } else {
            list = catalogService.findAll();
        }

        model.addAttribute("products", list);
        model.addAttribute("selectedType", type);
        model.addAttribute("searchName", name);
        return "products";
    }
}
