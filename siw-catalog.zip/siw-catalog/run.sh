#!/usr/bin/env bash
set -e
./mvnw -DskipTests spring-boot:run
