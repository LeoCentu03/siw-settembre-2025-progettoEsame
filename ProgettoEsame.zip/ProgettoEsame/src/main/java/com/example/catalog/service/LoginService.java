package com.example.catalog.service;

import org.springframework.stereotype.Service;

@Service
public class LoginService {

    public String getLoginPage() {
        return "login";
    }
}
