package com.example.catalog.service;

import com.example.catalog.model.Comment;
import com.example.catalog.model.Product;
import com.example.catalog.repo.CommentRepository;
import com.example.catalog.repo.ProductRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Service
public class ProductService {

    private final ProductRepository products;
    private final CommentRepository comments;

    public ProductService(ProductRepository products, CommentRepository comments) {
        this.products = products;
        this.comments = comments;
    }

    public List<Product> findAll() {
        return products.findAll();
    }

    public Product findById(Long id) {
        return products.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public void save(Product product) {
        products.save(product);
    }

    public void deleteById(Long id) {
        products.deleteById(id);
    }

    public List<Product> findAllByOrderByNameAsc() {
        return products.findAllByOrderByNameAsc();
    }

    public List<Product> findByTypeIgnoreCaseOrderByNameAsc(String type) {
        return products.findByTypeIgnoreCaseOrderByNameAsc(type);
    }

    public List<Product> findByNameContainingIgnoreCaseOrderByNameAsc(String name) {
        return products.findByNameContainingIgnoreCaseOrderByNameAsc(name);
    }

    public Product getProductWithSimilar(Long id) {
        return products.findByIdWithSimilar(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    }

    public List<Product> getSimilarProducts(Product product) {
        return product.getSimilarProducts() != null ? product.getSimilarProducts() : Collections.emptyList();
    }

    public List<Product> findAllExcept(Product product) {
        return products.findAll().stream()
                .filter(p -> !Objects.equals(p.getId(), product.getId()))
                .collect(Collectors.toList());
    }

    public List<String> getTypes() {
        return products.findAll().stream()
                .map(Product::getType)
                .filter(Objects::nonNull)
                .map(String::toLowerCase)
                .distinct()
                .sorted()
                .collect(Collectors.toList());
    }

    public List<Comment> getComments(Product product) {
        List<Comment> list = comments.findByProductOrderByCreatedAtDesc(product);
        return list != null ? list : Collections.emptyList();
    }

    public void addSimilar(Product product, Product similar) {
        product.addSimilar(similar);
        products.save(product);
    }

    public void removeSimilar(Product product, Long similarId) {
        product.removeSimilarById(similarId);
        products.save(product);
    }
}
