package com.example.catalog.web;

import com.example.catalog.model.Product;
import com.example.catalog.service.ProductService;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/admin/products")
public class AdminProductController {

    private final ProductService productService;

    public AdminProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public String list(Model model) {
        model.addAttribute("products", productService.findAll());
        return "admin/products/list";
    }

    @GetMapping("/new")
    public String createForm(Model model) {
        model.addAttribute("product", new Product());
        return "admin/products/form";
    }

    @PostMapping
    public String create(@ModelAttribute Product product) {
        productService.save(product);
        return "redirect:/admin/products";
    }

    @GetMapping("/{id}/edit")
    public String editForm(@PathVariable("id") Long id, Model model) {
        Product product = productService.findById(id);
        model.addAttribute("product", product);
        return "admin/products/form";
    }

    @PostMapping("/{id}")
    public String update(@PathVariable("id") Long id, @ModelAttribute Product form) {
        Product existing = productService.findById(id);
        existing.setName(form.getName());
        existing.setPrice(form.getPrice());
        existing.setDescription(form.getDescription());
        existing.setType(form.getType());
        productService.save(existing);
        return "redirect:/admin/products";
    }

    @PostMapping("/{id}/delete")
    public String delete(@PathVariable("id") Long id) {
        productService.deleteById(id);
        return "redirect:/admin/products";
    }

    @GetMapping("/{id}/similar")
    public String similar(@PathVariable("id") Long id, Model model) {
        Product product = productService.findById(id);
        List<Product> others = productService.findAllExcept(product);

        model.addAttribute("p", product);
        model.addAttribute("current", product.getSimilarProducts());
        model.addAttribute("others", others);
        return "admin/products/similar";
    }

    @PostMapping("/{id}/similar/add")
    public String addSimilar(@PathVariable("id") Long id, @RequestParam("similarId") Long similarId) {
        Product product = productService.findById(id);
        Product similar = productService.findById(similarId);
        product.addSimilar(similar);
        productService.save(product);
        return "redirect:/admin/products/" + id + "/similar";
    }

    @PostMapping("/{id}/similar/remove")
    public String removeSimilar(@PathVariable("id") Long id, @RequestParam("similarId") Long similarId) {
        Product product = productService.findById(id);
        product.removeSimilarById(similarId);
        productService.save(product);
        return "redirect:/admin/products/" + id + "/similar";
    }
}
